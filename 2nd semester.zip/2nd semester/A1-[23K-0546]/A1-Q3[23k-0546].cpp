#include <iostream>
using namespace std;

class chesspiece {
    string name;
    string color;
    char symbol;

public:
    chesspiece() {
        name = "Pawn";
        color = "White";
        symbol = 'P';
    }

    chesspiece(string n, string c, char s) {
        name = n;
        color = c;
        symbol = s;
    }
    string get_name() {return name;}
    string get_color() {return color; }
    char get_symbol() {return symbol;}
    void set_name(string na) {
        name = na;
    }
    void set_color(string co) {
        color = co;
}
    void set_symbol(char sy) {
        symbol = sy;
    }
};
class chessboard {
public:
    chesspiece* BOARD[8][8];

    chessboard() {
        
        for (int i = 0; i < 8; ++i) {
            
            for (int j = 0; j < 8; ++j) {
                BOARD[i][j] = nullptr; 
            }
        }
//        chessboard
        BOARD[0][0] = new chesspiece("Rook", "White", 'R');
        BOARD[0][1] = new chesspiece("Knight", "White", 'B');
        BOARD[0][2] = new chesspiece("Bishop", "White", 'B');
        BOARD[0][3] = new chesspiece("Queen", "White", 'Q');
        BOARD[0][4] = new chesspiece("King", "White", 'B');
        BOARD[0][5] = new chesspiece("Bishop", "White", 'B');
        BOARD[0][6] = new chesspiece("Knight", "White", 'N');
        BOARD[0][7] = new chesspiece("Rook", "White", 'R');
        BOARD[1][0] = new chesspiece("Pawn", "White", 'P');
        BOARD[1][1] = new chesspiece("Pawn", "White", 'P');
        BOARD[1][2] = new chesspiece("Pawn", "White", 'P');
        BOARD[1][3] = new chesspiece("Pawn", "White", 'P');
        BOARD[1][4] = new chesspiece("Pawn", "White", 'P');
        BOARD[1][5] = new chesspiece("Pawn", "White", 'P');
        BOARD[1][6] = new chesspiece("Pawn", "White", 'P');
        BOARD[1][7] = new chesspiece("Pawn", "White", 'P');

        for (int i = 2; i < 6; ++i) {
            for (int j = 0; j < 8; ++j) {
                BOARD[i][j] = nullptr;
            }}
//         black pieces
        BOARD[6][0] = new chesspiece("Pawn", "Black", 'p');
        BOARD[6][1] = new chesspiece("Pawn", "Black", 'p');
        BOARD[6][2] = new chesspiece("Pawn", "Black", 'p');
        BOARD[6][3] = new chesspiece("Pawn", "Black", 'p');
        BOARD[6][4] = new chesspiece("Pawn", "Black", 'p');
        BOARD[6][5] = new chesspiece("Pawn", "Black", 'p');
        BOARD[6][6] = new chesspiece("Pawn", "Black", 'p');
        BOARD[6][7] = new chesspiece("Pawn", "Black", 'p');

        BOARD[7][0] = new chesspiece("Rook", "Black", 'r');
        BOARD[7][1] = new chesspiece("Knight", "Black", 'n');
        BOARD[7][2] = new chesspiece("Bishop", "Black", 'b');
        BOARD[7][3] = new chesspiece("Queen", "Black", 'q');
        BOARD[7][4] = new chesspiece("King", "Black", 'k');
        BOARD[7][5] = new chesspiece("Bishop", "Black", 'b');
        BOARD[7][6] = new chesspiece("Knight", "Black", 'n');
        BOARD[7][7] = new chesspiece("Rook", "Black", 'r');
    }
    void display() {
        cout << "  a b c d e f g h" << endl;
        for (int i = 0; i < 8; ++i) {
            cout << 8 - i << " ";
            for (int j = 0; j < 8; ++j) {
                if (BOARD[i][j] == nullptr) {
                    cout << ". ";
                } else {
                    cout << BOARD[i][j]->get_symbol() << " ";
                }
            }
            cout << 8 - i << endl;
        }
        cout << "  a b c d e f g h" << endl;
    }

  //  moves of pawn and knights considered.
	bool movepiece(string source, string destination){	
		
		if (source == "b1" ){			
			if ( destination == "a3" || destination == "c3" ){
				return true;
			}
			else
				return false;
		}
		else if (source == "g1" ){			
			if ( destination == "f3" || destination == "h3" ){
				return true;
			}
			else
				return false;	
		}
		else if (source == "b8" ){	
			if (destination == "a6" || destination == "c6" ){
				return true;
			}
			else
				return false;
			
		}
		else if (source == "g8" ){		
			if (destination == "f6" || destination == "h6" ){
				return true;
			}
			else
				return false;
			
		}
		else if (source[1] == '7' ){	
			if (destination[1] == '6'  || destination[1] == '5' ){
				return true;
			}
			else
				return false;
		}	
		else if (source[1] == '2' ){	
			if (destination[1] == '3'  || destination[1] == '4' ){
				return true;}
			else
				return false;
		}
		else
			return false;
	}
    ~chessboard() {
        for (int i = 0; i < 8; ++i) {
            delete[] BOARD[i];
        }
        delete[] BOARD;}
};

int main() {
    cout << "MUHAMMAD ZOHAIB RAZA \t\t23K-0546" << endl << endl;
	chessboard board;
    board.display();
    cout <<  endl << endl;
    if (board.movepiece( "b8" ,"d7" ) == 1 ){
    	cout << " valid Move. "<< endl;	}
	else
		cout << " Invalid Move. "<< endl;	
	 cout <<  endl << endl;
    
    if (board.movepiece( "b8" ,"a6" ) == 1 ){
    	cout << " valid Move. "<< endl;}
	else
		cout << " Invalid Move. "<< endl;	
		cout<<"test cases has been tested"; 
}
