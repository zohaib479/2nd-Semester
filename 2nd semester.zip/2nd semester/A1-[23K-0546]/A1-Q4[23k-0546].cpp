#include <iostream>
using namespace std;
class Roller_Coaster
{
    string Name;
    float height;
    float length;
    double speed;
    int Capacity;
    int CurrentNumRiders;
    bool RideInProgress;

public:
    Roller_Coaster() : Name("roller coaster"), height(50), length(2000), Capacity(20), speed(150), CurrentNumRiders(15), RideInProgress(false) {}
    Roller_Coaster(string n, float h, float l, double s, int c, int curr)
    {
        RideInProgress = false;
        this->Name = n;
        this->height = h;
        this->length = l;
        this->speed = s;
        if (c > 3)
        {
            if (c % 2 == 0 || c % 3 == 0)
            {
                this->Capacity = c;
            }
            else
            {
                Capacity = c + 1;
            }
        }
        else
        {
            cout << "ENTERED INVALID CAPCAITY: ";
            exit(EXIT_FAILURE);
        }
        this->CurrentNumRiders = curr;
    }
    void set_Name(string na)
    {
        Name = na;
    }
    string get_Name() const
    {
        return Name;
    }
    void set_height(float h)
    {
        height = h;
    }
    float get_Height() const
    {
        return height;
    }
    void set_length(float l)
    {
        length = l;
    }
    float get_length() const
    {
        return length;
    }
    void set_speed(double s)
    {
        speed = s;
    }
    double get_speed() const
    {
        return speed;
    }
    void set_Capacity(int c)
    {
        if (c > 3)
        {
            if (c % 2 == 0 || c % 3 == 0)
            {
                this->Capacity = c;
            }
            else
            {
                Capacity = c + 1;
            }
        }
        else
        {
            cout << "ENTERED INVALID CAPCAITY: ";
            exit(EXIT_FAILURE);
        }
    }
    float get_capacity() const
    {
        return Capacity;
    }
    void set_CurrentNumRiders(int cur)
    {
        CurrentNumRiders = cur;
    }
    float get_CurrentNumRiders() const
    {
        return CurrentNumRiders;
    }
    void set_RideInProgress(int h)
    {
        RideInProgress = h;
    }
    int get_RideInProgress() const { return RideInProgress; }
    int seats()
    {
        if (!get_RideInProgress())
        {
            if (get_capacity() <= get_CurrentNumRiders())
            {
                cout << "SUCCESSFULLY SEATED: ";
                return 0;
            }
            else
                return (-1 * (get_capacity() - get_CurrentNumRiders()));
        }
        else
        {
            cout << "The ride is on way: ";
            exit(EXIT_FAILURE);
        }
    }
    int start()
    {
        if (!get_RideInProgress())
        {
            if (get_capacity() <= get_CurrentNumRiders())
            {
               cout<<endl<<"THE ride has been started"<<endl;
                return 0;
            }
            else
            {
                return (get_capacity() - get_CurrentNumRiders());
            }
        }
        else
            return -1;
    }

    void stop()
    {
        if (!get_RideInProgress())
        {
            cout << "Ride stopped";
            set_RideInProgress(0);
        }
        else
        {
            cout << "Ride is already stopped: " << endl;
            exit(EXIT_FAILURE);
        }
    }
    void unload()
    {
        if (get_RideInProgress())
        {
            Capacity = 0;
            cout<<endl<<"Successfully Unloaded"<<endl;
        }
        else
        {
            cout <<endl<< "Ride is in progress: " << endl;
//            exit(EXIT_FAILURE);
        }
    }
    void speedup()
    {
        if (!get_RideInProgress())
        {
            speed += 6; // 23k-0546
            cout<<endl<<"the current speed is    " <<speed<<endl;
        }
        else
        {
            cout << "Ride is  stopped: " << endl;
            exit(EXIT_FAILURE);
        }
    }
    void brake()
    {
        if (!get_RideInProgress())
        {
            speed -= 5; // 23k-0546
            cout<<endl<<"The brake is applied and the current speed is   "<<speed<<endl;
        }
        else
        {
            cout << "Ride is  stopped: " << endl;
            exit(EXIT_FAILURE);
        }
    }
};
int main()
{
	cout<<"MUHAMMAD ZOHAIB RAZA: \t23K-0546"<<endl;
    Roller_Coaster rc;
    rc.set_Capacity(70);
    rc.set_CurrentNumRiders(50);
    rc.set_length(1000);
    rc.set_Name("ROLLER COASTER");
    rc.set_RideInProgress(0);
    rc.set_speed(150);
    //
    Roller_Coaster y = Roller_Coaster("RAJPUT", 500, 2000, 200, 40, 45);
    y.seats();
    y.start();
    y.speedup();
    y.brake();
    cout<<"As we used the unload function:"<<endl;
    y.unload();
    y.stop();
}