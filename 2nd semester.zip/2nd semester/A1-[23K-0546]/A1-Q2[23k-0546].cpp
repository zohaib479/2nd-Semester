#include <iostream>
using namespace std;
class Table{
private:
    const int capacity;
    int occupiedSeats;
    bool clean;
public:
    Table():capacity(4),occupiedSeats(0),clean(true) {} 
    Table(int capacity):capacity(capacity),occupiedSeats(0),clean(true) {} 
    bool isClean()const
	 { 
	 return clean;
	 }
    int getFreeSeats() const
	 {
	  return capacity-occupiedSeats;
	 }
    int getCapacity() const
	 {
	  return capacity;
	 }
    void occupyTable(int groupSize)
	 {
        if (clean&&groupSize<=capacity)
		 {
            occupiedSeats = groupSize;
            clean = false;
           cout << "Table with capacity "<<capacity<<"   assigned to a group of "<<groupSize<<" people."<<endl;
        } 
		else
		 {
           cout << "No clean table available for a group of "<<groupSize<<" people"<<endl;
        }
    }
    void haveLunch() 
	{
        if (!clean) 
		{
            clean=true;
            cout<<"Lunch finished. Table is no longer clean."<<endl;
        } 
		else 
		{
            cout<<"Table is already clean."<<endl;
        }
    }
    void leaveTable(){
        occupiedSeats=0;
        cout<<"People left the table."<<endl;
    }
    void cleanTable()
	 {
        if (occupiedSeats==0) {
            clean = true;
            cout<<"Table cleaned."<<endl;
        } 
		else
		 {
           cout<<"Cannot clean table while people are seated."<<endl;
        }
    }
};
void OccupyTable(Table t[],int Size) {
    for (int i=0;i<5;++i) {
        if (t[i].isClean()&&Size<=t[i].getCapacity()) 
		{
            t[i].occupyTable(Size);
            return;
        }
    }
    cout<<"No clean table available for a group of "<<Size<<" people."<<endl;
}
void EmptyTable(Table t[],int Index) {
    t[Index].leaveTable();
    t[Index].cleanTable();
}
int main()
 {
 	
 	cout<<"MUHAMMAD ZOHAIB RAZA: \t 23K-0546"<<endl;
 	cout<<endl;
    Table tables[5] = {Table(8),Table(8),Table(4),Table(4),Table(4)};
    OccupyTable(tables, 5);  
    tables[0].haveLunch();    
    tables[0].leaveTable();  
    tables[0].cleanTable();    

    EmptyTable(tables, 1);
	   
    cout<<endl<<endl<<endl<<endl;
    tables[0].occupyTable(7); 
    tables[0].haveLunch();    
    tables[0].leaveTable();  
    tables[0].cleanTable();    

    EmptyTable(tables, 2);  

    return 0;
}
