#include<iostream>
#include<cstring>
using namespace std;
class Restaurant_h{
	string r_name;
	string location;
	string menu[3];
	int price[3];
	int bill;
	string valid_coupon_codes_list[3];
	 string coupons_redeemed_count[2];
	public:
	static int count ;
		Restaurant_h()
		{
			int bill=0;
			r_name="Food Haven";
			location="City Center";
			menu[0]="Sushi";
			menu[1]="Pad Thai";
			menu[2]="Mango Tango";
			price[0]=150;
			price[1]=1500;
			price[2]=2000;
			valid_coupon_codes_list[0]="FH-BOGO-12345";
			valid_coupon_codes_list[1]="FH-BOGO-12346";
			valid_coupon_codes_list[2]="FH-BOGO-12347";
			
		}
		void display_menu()
		{
			for(int i=0;i<3;i++)
			{
				cout<<endl<<"  items  "<<menu[i]<<"\t"<<price[i]<<"  "<<endl;
			}
		}
	float generate_bill(string n,string k="",string m="")
		{
			for(int i=0;i<3;i++)
			{
				
				if(menu[i]==n||menu[i]==k||menu[i]==m)
				{
					bill+=price[i];
				}
			}
			return bill;
		}
		void apply_discount(string j)
		{
			int percent=0;
			for(int i=0;i<3;i++)
			{
				if(valid_coupon_codes_list[i]==j)
				{
					cout<<endl<<"ENJOY YOUR MEAL"<<endl;
					percent=bill*0.1;
					bill-=percent;
				}
             else
            count++;
			}
		
			cout<<endl<<"The bill after discount is "<<bill<<" pkr "
			<<endl<<r_name<<endl<<location<<endl<<endl;}
};
int Restaurant_h::count=0;
class Restaurant_b{
	string r_name;
	string location;
	string menu[3];
	int price[3];
	int bill;
	string valid_coupon_codes_list[3];
	 string coupons_redeemed_count[2];
	static int count;
	public:
		Restaurant_b()
		{
			int bill=0;
			r_name="Pixel Bites";
			location="Cyber Street";
			menu[0]="Binary Burger";
			menu[1]="Quantum Quinoa";
			menu[2]="Data Donuts";
			price[0]=1250;
			price[1]=2500;
			price[2]=5000;
			valid_coupon_codes_list[0]="PB-BOGO-67890";
			valid_coupon_codes_list[1]="PB-BOGO-12345";
			valid_coupon_codes_list[2]="PB-BOGO-12346";
			
		}
		void display_menu()
		{
			for(int i=0;i<3;i++)
			{
				cout<<"  items  "<<menu[i]<<"\t"<<price[i]<<"  "<<endl;
			}
		}
	float generate_bill(string n,string k="",string m="")
		{
			for(int i=0;i<3;i++)
			{
				
				if(menu[i]==n||menu[i]==k||menu[i]==m)
				{
					bill+=price[i];
				}
			}
			return bill;
		}
		void apply_discount(string j)
		{
			int percent=0;
			for(int i=0;i<3;i++)
			{
				if(valid_coupon_codes_list[i]==j)
				{
					percent=bill*0.1;
					bill-=percent;
				}
								else
                              count++;
			}
			cout<<endl<<"The bill after discount is "<<bill<<" pkr "
			<<endl<<r_name<<endl<<location;
		}
};
int Restaurant_b::count=0;
class BOGOCoupon{
	string valid_from;
	string valid_until;
	string restaurant_code[2];
	public:
	string coupon_code[6];
	BOGOCoupon()
	{
		coupon_code[0]="PB-BOGO-67890";
		coupon_code[1]="PB-BOGO-12345";
		coupon_code[2]="PB-BOGO-12346";
		coupon_code[3]="FH-BOGO-12345";
		coupon_code[4]="FH-BOGO-12346";
		coupon_code[5]="FH-BOGO-12347";
		restaurant_code[0]="FH";
		restaurant_code[1]="PB";
	}
	bool valid(string s,string code)
	{
		for(int i=0;i<6;i++)
		{
			if(coupon_code[i]==s)
			{
				for(int i=0;i<2;i++)
				{
					if(restaurant_code[i]==code)
					{
				cout<<endl<<" VALID COUPON:"<<endl;
				return true;	
					}
					else
					{
					cout<<endl<<"INVALID COUPON"<<endl;
	             exit(EXIT_FAILURE);
					}
				}
			}
		}
	}
	void print()
	{
		for(int i=0;i<6;i++)
		{
			cout<<coupon_code[i]<<endl;
		}
	}
};
class USER{
	string name;
	int age ;
	string mobile_number;
	string *coupon;
	int size;

	public:
		USER()
		{
			size=6;
			coupon=new string[size];
		}
		USER(BOGOCoupon *obj)
		{		

			for(int i=0;i<size;i++)
	{
		coupon[i]=obj->coupon_code[i]; 
	}
		}
		void check(string s,string r_code)
		{
				BOGOCoupon obj;
				if(obj.valid(s,r_code))
				{
					cout<<endl<<"VALID CODE: "<<endl;
				}
				else
				{
					
				cout<<endl<<"INVALID:!!!!! "<<endl<<"Enter again: ";
				exit(EXIT_FAILURE);
				}
		}
		void set_name(string n,string p)
		{
			this->name=n;
			this->mobile_number=p;
		}
			string get_name()const
		{
			return name;
	
		}
				string get_number()const
		{
			return mobile_number;
	
		}
		void add_coupon(string c)
		{
			int l=size+1;
			coupon[l]=c;
		}
		void redeemed(string h)
		{
			for(int i=0;i<size;i++)
			{
				if(coupon[i]==h)
				{
					coupon[i]="";
				}
			}
			size--;
		}
	 
};
int main()
{
	cout<<"MUHAMMAD ZOHAIB RAZA:  \t\t 23K-0546";
	int valid_from,valid_till;
	Restaurant_h h1;
	Restaurant_b p1;
	USER u1;
	u1.set_name("ZOHAIB","0311-3141428");
	u1.check("FH-BOGO-12345","FH");
	h1.display_menu();
	h1.generate_bill("Mango Tango","Sushi");
	cout<<u1.get_name()<<endl;
	cout<<u1.get_number()<<endl;
	h1.apply_discount("FH-BOGO-12345");
		cout<<"Enter the validity date from which the coupon's validity starts: ";
	cin>>valid_from;
	cout<<"Enter the validity date till which the coupon is valid: ";
	cin>>valid_till;
	
		USER u2;
	u2.set_name("ZOHAIB","0311-3141428");
	u2.check("PB-BOGO-67890","FH");
	p1.display_menu();
	p1.generate_bill("Binary Burger","Quantum Quinoa");
		cout<<u1.get_name()<<endl;
	cout<<u1.get_number()<<endl;
		cout<<"Enter the validity date from which the coupon's validity starts: ";
	cin>>valid_from;
	cout<<"Enter the validity date till which the coupon is valid: ";
	cin>>valid_till;
	p1.apply_discount("PB-BOGO-67890");
	u2.add_coupon("PB-BOGO-67769");
	u2.redeemed("PB-BOGO-67890");
	
}