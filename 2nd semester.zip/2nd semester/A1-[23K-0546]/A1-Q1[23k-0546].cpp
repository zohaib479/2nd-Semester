#include<iostream>
#include<initializer_list>
using namespace std;
class pet{
	string healthStatus;
	int hunger_Level;
	int happinessLevel;
	 initializer_list<std::string> Skills;
	 int x,y;
	public:
		  pet(int i = 0, int j = 0, const initializer_list<std::string>& specialSkills = {})
        : x(i), y(j), Skills(specialSkills) {
    }
		void displayPetDetails(){
			cout<<"THE HEALTH STATUS IS :  "<<healthStatus
			<<endl<<"THE HAPPINESS LEVEL OF THE PET IS  "<<happinessLevel<<
			endl<<"THE HUNGER LEVEL OF THE PET IS  "<<hunger_Level<<endl;
					for(string skill:Skills){
					cout<<skill<<" ";
}
		}
		void updateHappiness(int m)
		{
			happinessLevel=m;
		}
		void updateHealth(string s)
		{
			healthStatus=s;
		}
		void updateHunger(int k)
		{
			hunger_Level=k;
		}
		bool check_Hunger()
		{
			
			if(hunger_Level<6)
			{
				happinessLevel--;
				return true;
			}
			else
			return false;
		}
		void feed()
		{
			happinessLevel=10;
			cout<<endl<<" PET IS HAPPY NOW"<<endl;
		}
};
class Adopter{
	string AdopterName;
	string adopterMobileNUm;
	pet *adoptedPetRecords[5];
	public:
			int num=0;
		Adopter()
		{
			AdopterName="ZOHAIB";
			adopterMobileNUm="0311-3141428";
			for(int i=0;i<5;i++)
			{
				adoptedPetRecords[i]=nullptr;
			}
		}
		void set_NAME(string s)
		{
			AdopterName=s;
		}
		void adoptPet(pet *p1)
		{
	   for(int i=0;i<5;i++)
	   {
	    	if(num<5)
	    	{
	    	adoptedPetRecords[num]= p1;
	    	num++;
			}
			return ;
	   }
	    	
	}
		void returnPet(pet *p)
		{
			for(int i=0;i<5;i++)
			{
				if(adoptedPetRecords[i]==p)
				{
					adoptedPetRecords[i]=nullptr;
					
				}
				num--;
			}
		}
		void displayAdoptedPets(){
			for(int i=0;i<num;i++)
			{
				
				if(adoptedPetRecords[i]!=nullptr)
				{
				 cout << "Adopted Pet  Details: " << endl;
                adoptedPetRecords[i]->displayPetDetails();
				}	
				
				
			}
			}
		
};

int main()
{
	cout<<"MUHAMMAD ZOHAIB RAZA : \t23k-0546"<<endl;
	pet p1(1,2,{"BEAUTIFUL VOICE"," GESTURES  ","  PLAY     "});
	p1.updateHappiness(6);
	p1.updateHealth("SICK");
	p1.updateHunger(5);
	cout<<endl<<endl<<"PET 1"<<endl;
	p1.displayPetDetails();
		if(p1.check_Hunger()){
		int ch;
			cout<<endl<<"THE pet is hungry!! IF you want to feed press 1"<<endl;
		cin>>ch;
		if(ch==1)
		{
		p1.feed();
		cout<<"HAPPINESS ALSO UPDATED"<<endl;
		}
	
		else 
		exit(EXIT_FAILURE);
	}
	pet p2(1,2,{"PERSIAN","JUMP","TALK"});
		p2.updateHappiness(9);
	p2.updateHealth("HEALTHY");
	p2.updateHunger(7);
	cout<<endl<<endl<<"PET 2"<<endl;
	p2.displayPetDetails();
		if(p2.check_Hunger()){
		int ch;
		cout<<endl<<"THE pet is hungry!! IF you want to feed press 1"<<endl;
		cin>>ch;
		if(ch==1)
		{
		p2.feed();
		}
	
		else 
		exit(EXIT_FAILURE);
	}
	
	pet p3(1,2,{"FIGHT","STAND","ENTERTAIN"});
		p3.updateHappiness(8);
	p3.updateHealth("MODERATE");
	p3.updateHunger(8);
	cout<<endl<<endl<<"PET 3"<<endl;
	p3.displayPetDetails();
		if(p3.check_Hunger()){
		int ch;
		cout<<endl<<"THE pet is hungry!! IF you want to feed press 1"<<endl;
		cin>>ch;
		if(ch==1)
		{
		p3.feed();
		}
		else 
		exit(EXIT_FAILURE);
	}
	Adopter a1,a2,a3;
	a1.adoptPet(&p1);
	a2.adoptPet(&p2);
	a3.adoptPet(&p3);
		cout<<endl<<endl<<"PET 1"<<endl;
	a1.displayAdoptedPets();
		cout<<endl<<endl<<"PET 2"<<endl;
	a2.displayAdoptedPets();
	cout<<endl<<endl<<"PET 3"<<endl;
	a3.displayAdoptedPets();
}