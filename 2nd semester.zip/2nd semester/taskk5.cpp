#include<iostream>
using namespace std;
const int MAX=100;
struct product{
 string p_name;
 float p_price;
 int p_id;
int p_quantity;
};
void addition(product p[],string name,float price,int quantity,int id)
{
    for(int i=2;i<MAX;i++)
    {
        if(p[i].p_name.empty())
        {
  p[i].p_name=name;
  p[i].p_id=id;
  p[i].p_price=price;
  p[i].p_quantity=quantity;
  break;
        }
        }
}
void find(product p[],int id)
{
    for(int i=0;i<MAX;i++)
    {
        if(p[i].p_id==id)
        {
            cout<<endl<<"name     :- "<< p[i].p_name;
            cout<<endl<<"price    :- "<< p[i].p_price;
            cout<<endl<<"quantity :- "<<p[i].p_quantity;
        }
    }
}
void update(product p[],int id,string u_name,float u_Price,int u_quantity)
{
    for(int i=0;i<MAX;i++)
    {
        if(p[i].p_id==id)
        {
        p[i].p_name=u_name;
        p[i].p_price=u_Price;
        p[i].p_quantity=u_quantity;
        }
    }
find(p,id);
   
}

void remove(product p[],int id,int &size)
{
    int index=-1;

    for(int i=0;i<MAX;i++)
    {
        if(p[i].p_id==id)
        {
            index=i;
            break;
        }
        
    }
    if(index==-1)
    {
        cout<<"invalid id: "<<endl;
        exit(EXIT_FAILURE);
    }
  for(int i=index;i<size-1;i++)
  {
    p[i]=p[i+1];
  }
  size--;
  cout<<"deleted Successfully::";
  find(p,id);
}
int main()
{
    int no_of_product;
    cout<<"enter the number of products: ";
    cin>>no_of_product;
 product p[no_of_product];
 p[0]={"cream",30,546,20};
 p[1]={"ice cream",40,246,30};
 p[3]={"tibet",57.8,430,21};
 int size=3;//initial;
 int choice;
cout<<"enter 1 for addition of new product : "<<endl<<"enter 2 for displaying the specific info : "<<endl<<"enter 3 for updation:"<<endl<<"enter 4 for removing a product: ";
cin>>choice;
if(choice==1)
{
string name;
float price;
int quantity;
int id;
for(int i=0;i<no_of_product;i++)
{
cout<<"enter the name: "<<endl;
cin>>name;
cout<<"enter the price: "<<endl;
cin>>price;
cout<<"enter the quantity :"<<endl;
cin>>quantity;
cout<<"enter the id : "<<endl;
cin>>id;
 addition(p,name,price,quantity,id);
}
}
if(choice==2)
{
    int find_id;
    cout<<"enter the id you want to search: ";
    cin>>find_id;
    find(p,find_id);
}
if(choice==3)
{
    int upd_id;
 cout<<"enter the id you want to update: ";
    cin>>upd_id;
    string u_name;
    cout<<"enter the updated name: ";
    cin>>u_name;
    float u_price;
     cout<<"enter the updated price: ";
    cin>>u_price;
    int u_quantity;
     cout<<"enter the updated quantity: ";
    cin>>u_quantity;
    update(p,upd_id,u_name,u_price,u_quantity);
}
if(choice==4)
{
    int deletee;
   cout<<"enter the id you want to delete : ";
   cin>>deletee;

   remove(p,deletee,size);
}
}

