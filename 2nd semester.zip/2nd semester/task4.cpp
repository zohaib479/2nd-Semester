#include<iostream>
using namespace std;
int main()
{
    int size;
    cout<<"enter the size of an array:";
    cin>>size;

    int *array;
    array=new int[size];
    for(int i=0;i<size;i++)
    {
        cin>>*(array+i);
    }
    int target ;
    cout<<"enter the targetted value";
    cin>>target;
    for(int i=0;i<size;i++)
    {
        for(int j=i+1;j<size;j++)
        {
            if(array[i]+array[j]==target)
            {
                cout<<endl;
               cout<<"["<<i<<" , "<<j<<"]";
            }
        }
    }
}