#include <iostream>
#include <string>
using namespace std;


template <class T>
class Pet {
protected:
    string name;
    int age;

public:
   
    Pet(const string n, int a) : name(n), age(a) {}   
    virtual void makeSound() = 0;
    void displayInfo() const {
        cout << "Name: " << name << ", Age: " << age << endl;
    }
};

class Cat : public Pet<Cat> {
public:
    Cat( string n, int a) : Pet<Cat>(n, a) {}

    
    void makeSound()  override {
        cout << "Meow!" << endl;
    }
};


class Dog : public Pet<Dog> {
public:
    Dog(string n, int a) : Pet<Dog>(n, a) {}

   
    void makeSound()  override {
        cout << "Woof!" << endl;
    }
};


class Bird : public Pet<Bird> {
public:
    Bird(string n, int a) : Pet<Bird>(n, a) {}

    
    void makeSound()  override {
        cout << "Chirp!" << endl;
    }
};

int main() {
   
    Cat myCat("Whiskers", 3);
    Dog myDog("Buddy", 5);
    Bird myBird("Polly", 2);

    
    cout << "My Cat: ";
    myCat.displayInfo();
    myCat.makeSound();

    cout << "My Dog: ";
    myDog.displayInfo();
    myDog.makeSound();

    cout << "My Bird: ";
    myBird.displayInfo();
    myBird.makeSound();

    return 0;
}
