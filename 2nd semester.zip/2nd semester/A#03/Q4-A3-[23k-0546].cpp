#include <iostream>
#include <cmath>
using namespace std;
class Drone {
protected:
    float longitude;
    float latitude;
    float altitude;
    float speed;
public:
    void adjustAltitude(float meters) {
        altitude = meters;
    }

    void setSpeed(float speed) {
        this->speed = speed;
    }
};
class Flyable {
public:
    virtual void takeoff() = 0;
    virtual void land() = 0;
    virtual void navigateTo(float latitude, float longitude, float altitude) = 0;
};
class Scannable {
public:
    virtual void scanArea(float radius) = 0;
};
class ReconDrone : public Drone, public Flyable, public Scannable {
private:
    int cameraResolution;
    float maxFlightTime;

public:
    ReconDrone(int resolution, float maxTime)
        : cameraResolution(resolution), maxFlightTime(maxTime) {}

    void takeoff() override {
        cout << "Drone is taking off." << endl;
    }

    void land() override {
        cout << "Drone is landing." << endl;
    }

    void navigateTo(float latitude, float longitude, float altitude) override {
        
        float distance = sqrt(pow(latitude - this->latitude, 2) + pow(longitude - this->longitude, 2));
        float timeRequired = distance / speed; 

        cout << "Navigating to (" << latitude << ", " << longitude << ", " << altitude << ")..." << endl;
        cout << "Estimated time to destination: " << timeRequired << " hours." << endl;
        this->latitude = latitude;
        this->longitude = longitude;
        this->altitude = altitude;
    }

    void scanArea(float radius) override {
        
        cout << "Scanning area within radius " << radius << " meters..." << endl;
       
        int numObjectsDetected = 5;
        cout << "Objects detected: " << numObjectsDetected << endl;
       
        for (int i = 0; i < numObjectsDetected; ++i) {
            float x = latitude + rand() % 100 - 50; 
            float y = longitude + rand() % 100 - 50;
            cout << "Object " << i + 1 << " at (" << x << ", " << y << ")" << endl;
        }
    }
};

int main() {

    ReconDrone drone(1080, 8.5); 
    drone.adjustAltitude(100);   
    drone.setSpeed(60);    
    drone.takeoff();
    drone.navigateTo(40.7128, -74.0060, 200); 
    drone.scanArea(500);                      
    drone.land();

    return 0;
}
