#include <iostream>
using namespace std;
class Medicine_Class
{
    string name;
    string formula;
    double retail_price;
    string manufacture_date;
    string expiration_date;

public:
    Medicine_Class() {retail_price=0;}
    Medicine_Class(string n, string f, double rp, string md, string ed)
    {
        this->name = n;
        this->formula = f;
        this->retail_price = rp;
        this->manufacture_date = md;
        this->expiration_date = ed;
    }
    void set_name(string n) { name = n; }
    void set_formula(string f) { formula = f; }
    void set_retail_price(double r) { retail_price += r; }
    void set_manufacture_date(string m) { manufacture_date = m; }
    void set_expiration_date(string e) { expiration_date = e; }

    string return_name() const { return name; }
    string return_formula() const { return formula; }
    double return_retail_price() const { return retail_price; }
    string return_manufacture_date() const { return manufacture_date; }
    string return_expiration_date() const { return expiration_date; };
    virtual void display()
    {
        cout << "MEDICINE NAME: " << name << endl
             << "MEDICINE FORMULA " << formula << endl
             << "RETAIL PRICE : " << retail_price << endl
             << "MANUFACTURE DATE: " << manufacture_date << endl
             << "EXPIRATION DATE: " << expiration_date << endl
             << endl;
    }
};
class Tablet:public Medicine_Class{
 protected:
 float sucrose_level;
 public:
 Tablet(){}
 Tablet(float level,string n,string f,double rp,string md,string ed):Medicine_Class(n,f,rp,md,ed){
    if(level<=1&&level>=0)
    {
        sucrose_level=level;
    }
    else
    {
        cout<<"INVALID SUCROSE LEVEL: "<<endl;
        exit(EXIT_FAILURE);
    }
    }
 void display()override{
    Medicine_Class::display();
    cout<<"SUCROSE LEVEL: "<<sucrose_level<<endl;
 }
};
class Capsule:public Medicine_Class
{ protected:
   float absorption_percentage;
   public:
   Capsule(){}
   Capsule(float p,string n,string f,double rp,string md,string ed):Medicine_Class(n,f,rp,md,ed)
   {
    if(p>=1&&p<=100)
    {
        absorption_percentage=p;
    }
   }
   void display()override{
    Medicine_Class::display();
    cout<<"ABSORPTION LEVEL: "<<absorption_percentage<<endl;
   }
};
class Syrup:public Medicine_Class{
  public:
   Syrup(float p,string n,string f,double rp,string md,string ed):Medicine_Class(n,f,rp,md,ed){}
   void display()override{

    cout<<"SYRUP DETAILS : "<<endl;
        Medicine_Class::display();
   }

};
class Pharmacist{
  public:
  void search_Medicine(string formula)
  {
    Medicine_Class *m;
    if(m->return_formula()==formula)
    {
        m->display();
    }

  }
};
class Counter{
  public:
  void search_Medicine(string n)
  {
    Medicine_Class *m;
    if(m->return_name()==n)
    {
        m->display();
    }
  }
  void update_Revenue(double r)
  {
    Medicine_Class *m;
    m->set_retail_price(r);
  }
};
 bool operator ==(Medicine_Class &m1,Medicine_Class &m2)
 {
    if(m1.return_expiration_date()==m2.return_expiration_date())
    {
        return true;
    }
    else
    {
        cout<<"NOT GOING TO EXIPER IN SAME YEAR : "<<endl;
        exit(EXIT_FAILURE);
    }
 }
int main() {
    
    Tablet tablet(0.5, "Paracetamol", "Acetaminophen", 5.99, "2022-04-28", "2023-04-28");
    Capsule capsule(80, "Omeprazole", "Proton Pump Inhibitor", 9.99, "2022-03-15", "2023-03-15");
    Syrup syrup(10, "Cough Syrup", "Dextromethorphan", 7.49, "2022-05-10", "2023-05-10");

   
    cout << "TABLET DETAILS:" << endl;
    tablet.display();
    cout << endl;

    cout << "CAPSULE DETAILS:" << endl;
    capsule.display();
    cout << endl;

    cout << "SYRUP DETAILS:" << endl;
    syrup.display();
    cout << endl;

  
    Pharmacist pharmacist;
    cout << "SEARCHING FOR MEDICINE BY FORMULA:" << endl;
    pharmacist.search_Medicine("Proton Pump Inhibitor");
    cout << endl;

  
    Counter counter;
    cout << "SEARCHING FOR MEDICINE BY NAME:" << endl;
    counter.search_Medicine("Paracetamol");
    cout << endl;

    
    cout << "UPDATING RETAIL PRICE OF A MEDICINE:" << endl;
    counter.update_Revenue(6.99); // New retail price
    cout << "Retail price updated successfully!" << endl;
    cout << endl;

   
    Medicine_Class m1("Test Medicine 1", "Test Formula", 10.99, "2022-06-30", "2023-06-30");
    Medicine_Class m2("Test Medicine 2", "Test Formula", 8.49, "2022-06-30", "2023-06-30");

    cout << "COMPARING TWO MEDICINES BY EXPIRATION DATE:" << endl;
    if (m1 == m2) {
        cout << "Both medicines expire in the same year." << endl;
    } else {
        cout << "Medicines expire in different years." << endl;
    }
    return 0;
}