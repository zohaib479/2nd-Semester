#include <iostream>
#include <stdexcept>
using namespace std;

template <class T>
class MATRIX {
public:
    T **arr;
    int rows;
    int cols;

    MATRIX(int r, int c) : rows(r), cols(c) {
        arr = new T*[rows];
        for (int i = 0; i < rows; i++) {
            arr[i] = new T[cols]();
        }
    }

    MATRIX(const MATRIX<T>& other) : rows(other.rows), cols(other.cols) {
        arr = new T*[rows];
        for (int i = 0; i < rows; i++) {
            arr[i] = new T[cols];
            for (int j = 0; j < cols; j++) {
                arr[i][j] = other.arr[i][j];
            }
        }
    }

    MATRIX<T>& operator=(const MATRIX<T>& other) {
        if (this != &other) {
     
            for (int i = 0; i < rows; i++) {
                delete[] arr[i];
            }
            delete[] arr;

            
            rows = other.rows;
            cols = other.cols;
            arr = new T*[rows];
            for (int i = 0; i < rows; i++) {
                arr[i] = new T[cols];
                for (int j = 0; j < cols; j++) {
                    arr[i][j] = other.arr[i][j];
                }
            }
        }
        return *this;
    }
     void setElement(int row, int col, T value) {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            arr[row][col] = value;
        } else {
            cout << "Invalid index. Out of bounds." << endl;
        }
    }

    T getElement(int row, int col) const {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            return arr[row][col];
        } else {
            cout << "Invalid index. Out of bounds." << endl;
            return T(); 
        }
    }

    virtual MATRIX<T> operator+(const MATRIX<T>& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw invalid_argument("Matrix dimensions must be the same for addition.");
        }

        MATRIX<T> result(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.arr[i][j] = arr[i][j] + other.arr[i][j];
            }
        }
        return result;
    }

    virtual MATRIX<T> operator-(const MATRIX<T>& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw invalid_argument("Matrix dimensions must be the same for subtraction.");
        }

        MATRIX<T> result(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.arr[i][j] = arr[i][j] - other.arr[i][j];
            }
        }
        return result;
    }

    virtual MATRIX<T> operator*(const MATRIX<T>& other) const {
        if (cols != other.rows) {
            throw invalid_argument("Number of columns in the first matrix must match the number of rows in the second matrix for multiplication.");
        }

        MATRIX<T> result(rows, other.cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < other.cols; j++) {
                for (int k = 0; k < cols; k++) {
                    result.arr[i][j] += arr[i][k] * other.arr[k][j];
                }
            }
        }
        return result;
    }

    virtual void display() const {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                cout << arr[i][j] << " ";
            }
            cout << endl;
        }
    }

    virtual ~MATRIX() {
        for (int i = 0; i < rows; i++) {
            delete[] arr[i];
        }
        delete[] arr;
    }
};

class IntMatrix : public MATRIX<int> {
public:
    IntMatrix(int r, int c) : MATRIX<int>(r, c) {}

    
    IntMatrix(const MATRIX<int>& other) : MATRIX<int>(other) {}

    
    IntMatrix& operator=(const MATRIX<int>& other) {
        MATRIX<int>::operator=(other);
        return *this;
    }
};

class DoubleMatrix : public MATRIX<double> {
public:
    DoubleMatrix(int r, int c) : MATRIX<double>(r, c) {}
};

int main() {
    IntMatrix *intMat=new IntMatrix(2, 2);
    IntMatrix *intMat1=new IntMatrix(2, 2);

    intMat->setElement(0, 0, 1);
    intMat->setElement(0, 1, 2);
    intMat->setElement(1, 0, 3);
    intMat->setElement(1, 1, 4);

    intMat1->setElement(0, 0, 5);
    intMat1->setElement(0, 1, 6);
    intMat1->setElement(1, 0, 7);
    intMat1->setElement(1, 1, 8);
    
    
    intMat->display();
    cout<<endl<<endl;
    intMat1->display();
    cout<<endl<<endl;

    IntMatrix intMat2 = *(intMat) + *(intMat1);
    cout << "Result of addition:" << endl;
    
    intMat2.display();
    
    
    
     IntMatrix intMat3 = *(intMat) * *(intMat1);
    cout << "Result of Multiplication:" << endl;
    intMat3.display();
    
     IntMatrix intMat4 = *(intMat) - *(intMat1);
    cout << "Result of Subtraction:" << endl;
    intMat4.display();

    return 0;
}
