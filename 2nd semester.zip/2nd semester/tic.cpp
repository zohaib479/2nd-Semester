#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include<windows.h>

using namespace std;

const int BOARD_SIZE = 3;
const char EMPTY_CELL = ' ';
const char AI_PLAYER = 'X';
const char HUMAN_PLAYER = 'O';

// Function prototypes
void gotoxy (int x, int y)
 {
	COORD c;
	c.X=x;
	c.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}
void load_screen() {
	system("cls");
	gotoxy(50, 7);
	printf("RAJPUT");
	printf("\x1b[33m Loading ...");
	gotoxy(50, 8);
	for (int i=1; i<=20;i++) {
		for (int j=0; j<=10000000; j++);
		printf("%c", 219);
	}
	system("cls");
}
void initializeBoard(vector<vector<char>> &board);
void printBoard(const vector<vector<char>> &board);
bool isMoveValid(const vector<vector<char>> &board, int row, int col);
bool isBoardFull(const vector<vector<char>> &board);
bool checkForWin(const vector<vector<char>> &board, char player);
void playerMove(vector<vector<char>> &board);
void aiMove(vector<vector<char>> &board);
pair<int, int> minimax(vector<vector<char>> board, int depth, bool maximizingPlayer);
int evaluate(const vector<vector<char>> &board);

int main() {
    vector<vector<char>> board(BOARD_SIZE, vector<char>(BOARD_SIZE, EMPTY_CELL));
    initializeBoard(board);
load_screen();
    while (!isBoardFull(board) && !checkForWin(board, AI_PLAYER) && !checkForWin(board, HUMAN_PLAYER)) {
        printBoard(board);
        playerMove(board);
        if (checkForWin(board, HUMAN_PLAYER)) {
            cout << "Congratulations! You won!" << endl;
            break;
        }
        if (isBoardFull(board)) {
            cout << "It's a draw!" << endl;
            break;
        }
        aiMove(board);
        if (checkForWin(board, AI_PLAYER)) {
            printBoard(board);
            cout << "Sorry, you lost. Better luck next time!" << endl;
            break;
        }
    }

    return 0;
}

void initializeBoard(vector<vector<char>> &board) {
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            board[i][j] = EMPTY_CELL;
        }
    }
}

void printBoard(const vector<vector<char>> &board) {
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            cout << board[i][j] << " ";
        }
        cout << endl;
    }
}

bool isMoveValid(const vector<vector<char>> &board, int row, int col) {
    return (row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE && board[row][col] == EMPTY_CELL);
}

bool isBoardFull(const vector<vector<char>> &board) {
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (board[i][j] == EMPTY_CELL) {
                return false;
            }
        }
    }
    return true;
}

bool checkForWin(const vector<vector<char>> &board, char player) {
    // Check rows and columns
    for (int i = 0; i < BOARD_SIZE; ++i) {
        if ((board[i][0] == player && board[i][1] == player && board[i][2] == player) ||
            (board[0][i] == player && board[1][i] == player && board[2][i] == player)) {
            return true;
        }
    }
    // Check diagonals
    if ((board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
        (board[0][2] == player && board[1][1] == player && board[2][0] == player)) {
        return true;
    }
    return false;
}

void playerMove(vector<vector<char>> &board) {
    int row, col;
    cout << "Enter your move (row and column): ";
    cin>> row >> col;
    while (!isMoveValid(board, row, col)) {
        cout << "Invalid move! Try again: ";
        cin >> row >> col;
    }
    board[row][col] = HUMAN_PLAYER;
}

void aiMove(vector<vector<char>> &board) {
    // Check for potential winning moves
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (isMoveValid(board, i, j)) {
                board[i][j] = AI_PLAYER;
                if (checkForWin(board, AI_PLAYER)) {
                    return;
                }
                board[i][j] = EMPTY_CELL;
            }
        }
    }

    // Block human's winning moves
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (isMoveValid(board, i, j)) {
                board[i][j] = HUMAN_PLAYER;
                if (checkForWin(board, HUMAN_PLAYER)) {
                    board[i][j] = AI_PLAYER;
                    return;
                }
                board[i][j] = EMPTY_CELL;
            }
        }
    }

    // If no winning move, just make any available move
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (isMoveValid(board, i, j)) {
                board[i][j] = AI_PLAYER;
                return;
            }
        }
    }
}
