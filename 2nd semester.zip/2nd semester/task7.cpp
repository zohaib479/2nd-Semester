#include<iostream>
using namespace std;
int main()
{
    int size;
    cout<<"enter the size of an array:";
    cin>>size;
    int *array;
    array=new int[size];
    for(int i=0;i<size;i++)
    {
        cin>>*(array+i);
    }
    int a=array[size-1];
    cout<<a*a;
}