#include<iostream>
#include<cstring>
using namespace std;
int main()
{
  char *str;
  str=new char[1000];
  gets(str);
  int x;
  x=strlen(str);
  char *rev;
  rev=new char[x+1];
  for(char i=x;i>=0;i--)
  {
    rev=strrev(str);
  }
  cout<<strrev(rev);

     delete[] str,rev;
}