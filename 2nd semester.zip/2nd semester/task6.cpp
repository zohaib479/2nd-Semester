#include<iostream>

using namespace std;
void transpose(int **array,int rows,int cols)
{
    for(int i=0;i<rows;i++)
    {
        for(int j=i+1;j<cols;j++)
        {
            int temp;
            temp= array[i][j];
            array[i][j]=array[j][i];
            array[j][i]=temp;
        }
    }


    for(int i=0;i<rows;i++)
    {
        for(int j=0;j<cols;j++)
        {
            cout<<array[i][j]<<"  ";
        }
        cout<<endl;
    }
}
int main()
{
    int rows,cols;
    cout<<"enter the no of rows :";
    cin>>rows;
    cout<<endl<<"enter the no of columns:";
    cin>>cols;
    int **array;
    array=new int*[rows];
    for(int i=0;i<rows;i++)
    {
        *(array+i)=new int[cols];
    }
    cout<<"inputting the values: ";
    cout<<endl;
    for(int i=0;i<rows;i++)
    {
        for(int j=0;j<cols;j++)
        {
            cin>>*(*(array+i)+j);
        }
    }
    transpose(array,rows,cols);

    for(int i=0;i<rows;i++)
    {
        delete[] array;
    }
    delete[] array;
}
