#include<iostream>
using namespace std;
class stock{
 char symbol;
 string name;
 int current_price;
 int previous_closing_price;

 public:
double getChangePercent()
 {
return static_cast<double>(current_price-previous_closing_price)/current_price*100.0 ;
 }
 void setSymbol(char ch)
 {
   symbol=ch;
 }
  void setCurrentPrice(int price)
  {
    current_price=price;
  }
  void SetPreviousClosingPrice(int p)
  {
  previous_closing_price=p;
  }
  void SetName(string n)
  {
    name=n;
  }
 void getPreviousClosingPrice()
 {
    cout<<endl<<"the last price was: "<<previous_closing_price;
 }
 void getCurrentPrice()
 {
    cout<<endl<<"the current price is : "<<current_price;
 }

};
int main()
{
    stock s;
    s.setCurrentPrice(300);
    s.SetPreviousClosingPrice(200);
    double get=s.getChangePercent();
    cout<<endl<<"The decrease in percentage is "<<get<<"%";
    s.setSymbol('^');
    s.SetName("ajmal");
    s.getPreviousClosingPrice();
    s.getCurrentPrice();
}