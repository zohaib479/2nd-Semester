#include <iostream>
#include <string>
/* mam in this program 4 test book are saved and it will save newely added 
and previously added both data  and save upto 100 books data . */
using namespace std;
 struct book {
    string title;
    string author;
    int year;
    int quantity;
 }b[100];
 int add_book(int i){
    cout<<"book title :";
    cin>>b[i].title;
    cout<<"book author :";
    cin>>b[i].author;
    cout<<"book quantity :";
    cin>>b[i].quantity;
    cout<<"book year:";
    cin>>b[i].year;   
    cout << "book add successfully";
    return i+1;
 }
 void display_book(int c)
 {
    for (int i = 0; i < c; i++)
    {
   cout<<"book title :"<<b[i].title<<endl;
    cout<<"book author :"<<b[i].author<<endl;
    cout<<"book quantity :"<<b[i].quantity<<endl;
    cout<<"book year:"<<b[i].year<<endl;   
    cout<<"--------" <<endl;
    }
    
 }
 int search_book(int c)
 {
    string z;
    cout<<"enter book title :";
    cin>>z;
    for (int i = 0; i < c; i++)
    {
        if (b[i].title==z)
        {
    cout<<"book title :"<<b[i].title<<endl;
    cout<<"book author :"<<b[i].author<<endl;
    cout<<"book quantity :"<<b[i].quantity<<endl;
    cout<<"book year:"<<b[i].year<<endl;   
        }
        
    }
    
 }
 int check_book(int c)
 {
     string z;
    cout<<"enter book title  to buy:";
    cin>>z;
    for (int i = 0; i < c; i++)
    {
        if (b[i].title==z)
        {b[i].quantity=b[i].quantity-1;
            
    cout<<"done successfully";
        }
        
    }
 }
  int return_book(int c)
 {
     string z;
    cout<<"enter book title  to return:";
    cin>>z;
    for (int i = 0; i < c; i++)
    {
        if (b[i].title==z)
        {b[i].quantity=b[i].quantity+1;
            
    cout<<"done successfully";
        }
        
    }
 }
 int main(){
    int a,n=4;
    b[0]={"Book", "Author", 2000, 8};
    b[1]={"Book1", "Author1", 2020, 5};
    b[2]={"Book2", "Author2", 2018, 3};
    b[3]={"Book3", "Author3", 2022, 7};
    cout << "1: Add book  \n 2: display all books:\n3: search for a book\n4: check out a book\n5: return a book :";
    cin >> a;
    
    switch (a)
    {
    case 1:
       n= add_book(n);
        break;
    case 2:
        display_book(n);
        break;
    case 3:
        search_book(n);
        break;
    case 4:
        check_book(n);
        break;
    case 5:
        return_book(n);
        break;
    
    default:
    cout << "invalid";
        break;
    }


}