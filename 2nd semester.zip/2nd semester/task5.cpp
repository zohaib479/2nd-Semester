#include<iostream>
using namespace std;

void spiral(int **array,int rows,int cols)
{
   int bottom=rows-1,left=0,right=cols-1,top=0;
   while(left<=right&&top<=bottom)
   {

   
   for(int i=left;i<=right;i++)
   {
    cout<<" "<<array[top][i];

   }
       top++;

    for(int i=top;i<=bottom;i++)
    {
        cout<<" "<<array[i][right];
    }
    right--;


    for(int i=right;i>=left;i--)
    {
       cout<<" "<<array[bottom][i];
    }
    bottom--;
   
  
    for(int i=bottom;i>=top;i--)
    {
        cout<<" "<<array[i][left];
    }
    left++;
   }
}
int main()
{
    int rows,cols;
    cout<<"enter no of rows :"<<endl;
    cin>>rows;
    cout<<"enter no of cols : "<<endl;
    cin>>cols;
    int **array;
    array=new int*[rows];
    for(int i=0;i<rows;i++)
    {
        *(array+i)=new int[cols];
    }
    for(int i=0;i<rows;i++)
    {
        for(int j=0;j<cols;j++)
        {
          cin>>*(*(array+i)+j);
        }
        
    }

    spiral(array,rows,cols); 

    for(int i=0;i<rows;i++)
    {
        delete[] array;
    }
    delete[] array;

}