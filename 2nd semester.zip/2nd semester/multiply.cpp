#include<iostream>
using namespace std;

void multiply(int **arr1,int **arr2,int r1,int c1,int r2,int c2)
{
	int **arr3;
	arr3=new int*[r1];
	for(int i=0;i<r1;i++)
	{
		*(arr3+i)=new int[c2];
		 fill(arr3[i], arr3[i] + c2, 0);
	}
	
	for(int i=0;i<r1;i++)
	{
		for(int j=0;j<c2;j++)
		{
			for(int k=0;k<c1;k++)
			{
				arr3[i][j]+=arr1[i][k]*arr2[k][j];
			}
		}
	}
	
	for(int i=0;i<r1;i++)
	{
		for(int j=0;j<c2;j++)
		{
			cout<< "   "<<arr3[i][j];
		}
		cout<<endl;
	}
	
	
	for(int i=0;i<r1;i++)
	{
		delete[] arr3[i];
	}
	delete[] arr3;
}
int main()
{
   int rows1,cols1,rows2,cols2;
   cout<<"enter the rows of 1st matrix: ";
   cin>>rows1;
   cout<<endl<<"enter the no cols of 1st matrix: ";
   cin>>cols1;
   cout<<"enter the rows of 2nd matrix: ";
   cin>>rows2;
   cout<<endl<<"enter the cols of matrix 2: ";
   cin>>cols2;
   if(cols1!=rows2)
   {
   	 exit(EXIT_FAILURE);
   }
   else
   {
   	int **arr1;
   	int **arr2;
   	arr1=new int*[rows1];
   	arr2=new int*[rows2];
   	for(int i=0;i<rows1;i++)
   	{
   		*(arr1+i)=new int[cols1];
	}
		for(int i=0;i<rows2;i++)
   	{
   		*(arr2+i)=new int[cols2];
	}
	cout<<endl<<"enter the value for 1st matrix : "<<endl;
	for(int i=0;i<rows1;i++)
	{
		for(int j=0;j<cols1;j++)
		{
			cin>>arr1[i][j];
		}
	}
		cout<<endl<<"enter the value for 2nd matrix : "<<endl;
		for(int i=0;i<rows2;i++)
	{
		for(int j=0;j<cols2;j++)
		{
			cin>>arr2[i][j];
		}
	}
	
	multiply(arr1,arr2,rows1,cols1,rows2,cols2);
	for(int i=0;i<rows1;i++)
	{
		delete[] arr1[i];
	}
	delete[] arr1;
	for(int i=0;i<rows2;i++)
	{
		delete[] arr2[i];
	}
	delete[] arr2;
   }
}